// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Th\u00e8me multi-fen\u00eatres",_layout_default:"Mise en page par d\u00e9faut",_layout_layout1:"Mise en page\u00a01",emptyDocablePanelTip:"Cliquez sur le bouton + sous l'onglet Widget pour ajouter un widget. ",_localized:{}}});