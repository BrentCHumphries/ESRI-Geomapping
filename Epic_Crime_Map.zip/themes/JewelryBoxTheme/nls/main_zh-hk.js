// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"\u73e0\u5bf6\u7bb1\u4e3b\u984c",_layout_default:"\u9810\u8a2d\u7248\u9762\u914d\u7f6e",_layout_layout1:"\u7248\u9762\u914d\u7f6e 1",emptyDocablePanelTip:"\u5728\u300cWidget\u300d\u9801\u7c64\u4e2d\u6309\u4e00\u4e0b\u300c+\u300d\u6309\u9215\u4ee5\u65b0\u589e widget\u3002 ",_localized:{}}});