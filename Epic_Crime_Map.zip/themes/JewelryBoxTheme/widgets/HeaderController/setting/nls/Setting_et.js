// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/widgets/HeaderController/setting/nls/strings":{group:"Nimi",openAll:"Ava k\u00f5ik paneelis",dropDown:"N\u00e4ita rippmen\u00fc\u00fcs",noGroup:"Vidina gruppi pole m\u00e4\u00e4ratud.",groupSetLabel:"M\u00e4\u00e4ra vidina gruppide omadused",_localized:{}}});