// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/widgets/DartController/nls/strings":{_widgetLabel:"\u0921\u093e\u0930\u094d\u091f \u0928\u093f\u092f\u0902\u0924\u094d\u0930\u0915",_localized:{}}});