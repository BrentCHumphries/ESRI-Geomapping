// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/nls/strings":{_themeLabel:"Ch\u1ee7 \u0111\u1ec1 Cao nguy\u00ean",_layout_default:"B\u1ed1 c\u1ee5c m\u1eb7c \u0111\u1ecbnh",_layout_layout1:"B\u1ed1 c\u1ee5c 1",_localized:{}}});