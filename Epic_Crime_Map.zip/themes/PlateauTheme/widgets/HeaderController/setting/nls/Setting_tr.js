// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/setting/nls/strings":{group:"Ad\u0131",openAll:"T\u00fcm\u00fcn\u00fc Panoda A\u00e7",dropDown:"A\u00e7\u0131l\u0131r Men\u00fcde G\u00f6ster",noGroup:"Ayarlanm\u0131\u015f ara\u00e7 grubu yok.",groupSetLabel:"Ara\u00e7 grubu \u00f6zelliklerini ayarla",_localized:{}}});