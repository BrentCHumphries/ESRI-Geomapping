// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Yl\u00e4tunnisteen hallinta",signin:"Kirjaudu sis\u00e4\u00e4n",signout:"Kirjaudu ulos",about:"Tietoja",signInTo:"Kirjaudu palveluun",cantSignOutTip:"Toiminto ei ole k\u00e4ytett\u00e4viss\u00e4 esikatselutilassa.",more:"lis\u00e4\u00e4",_localized:{}}});