// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"N\u00e1zev",openAll:"Otev\u0159\u00edt v\u0161e v panelu",dropDown:"Zobrazit v rozbalovac\u00ed nab\u00eddce",noGroup:"Nen\u00ed nastavena \u017e\u00e1dn\u00e1 skupina widget\u016f.",groupSetLabel:"Nastavit vlastnosti skupin widget\u016f",_localized:{}}});